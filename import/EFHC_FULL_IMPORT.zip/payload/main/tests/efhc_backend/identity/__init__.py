"""Identity contract tests."""
